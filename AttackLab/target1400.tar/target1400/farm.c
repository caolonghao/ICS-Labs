/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_172(unsigned x)
{
    return x + 3348140120U;
}

void setval_131(unsigned *p)
{
    *p = 1481191551U;
}

void setval_358(unsigned *p)
{
    *p = 3347663100U;
}

unsigned getval_428()
{
    return 3281031256U;
}

void setval_148(unsigned *p)
{
    *p = 410400520U;
}

void setval_439(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_490(unsigned x)
{
    return x + 3267856712U;
}

unsigned getval_441()
{
    return 2428963144U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_214(unsigned x)
{
    return x + 3223896457U;
}

void setval_451(unsigned *p)
{
    *p = 3224945037U;
}

unsigned addval_265(unsigned x)
{
    return x + 3372799497U;
}

void setval_449(unsigned *p)
{
    *p = 3269495112U;
}

unsigned getval_250()
{
    return 3766569084U;
}

unsigned getval_414()
{
    return 3599245206U;
}

unsigned getval_336()
{
    return 3527985801U;
}

unsigned addval_351(unsigned x)
{
    return x + 3525886345U;
}

void setval_244(unsigned *p)
{
    *p = 3531915657U;
}

unsigned getval_231()
{
    return 3374369417U;
}

unsigned addval_339(unsigned x)
{
    return x + 2425542281U;
}

unsigned getval_430()
{
    return 3286272328U;
}

unsigned getval_312()
{
    return 3531915657U;
}

void setval_198(unsigned *p)
{
    *p = 3676359304U;
}

void setval_320(unsigned *p)
{
    *p = 2425539209U;
}

void setval_435(unsigned *p)
{
    *p = 2447411528U;
}

unsigned addval_499(unsigned x)
{
    return x + 3677929864U;
}

void setval_225(unsigned *p)
{
    *p = 2496301507U;
}

void setval_181(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_104()
{
    return 3523789192U;
}

unsigned addval_149(unsigned x)
{
    return x + 3232025225U;
}

void setval_353(unsigned *p)
{
    *p = 3677935241U;
}

unsigned addval_227(unsigned x)
{
    return x + 3680556681U;
}

unsigned getval_139()
{
    return 3372799627U;
}

unsigned getval_431()
{
    return 2497743176U;
}

unsigned addval_232(unsigned x)
{
    return x + 3281049225U;
}

unsigned addval_204(unsigned x)
{
    return x + 3677405577U;
}

unsigned addval_168(unsigned x)
{
    return x + 3286272264U;
}

unsigned getval_281()
{
    return 3677935240U;
}

unsigned addval_444(unsigned x)
{
    return x + 3523267209U;
}

unsigned getval_276()
{
    return 3674786441U;
}

unsigned getval_246()
{
    return 2464188744U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
